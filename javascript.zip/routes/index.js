var express = require('express');
var router = express.Router();
var us_states = require('../us_state.js');
const fetch = require('node-fetch')


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Find My Election', states: us_states });
});

//declare state and place
let state, place;


// search and fetch to api with state, place
async function searchElection(state, place) {
  try {
    const resp = await fetch(`https://api.turbovote.org/elections/upcoming?district-divisions=ocd-division/country:us/state:${state},ocd-division/country:us/state:${state}/place:${place}`, {
    method: 'GET',
    headers: {
      Accept: 'application/json'
    }
  })
    let data = resp.json()
    return data
  } catch(err) {
    console.log(err)
    }
}

//get results page
router.get('/electionResults', async function(req, res, next) {
  const results = await searchElection(state, place);

    res.render('electionResults', {
      electionResults: results[0]
   })
})


// submit form
router.post('/search', function(req, res, next) {
   state = req.body.state.toLowerCase();
   place = req.body.city.toLowerCase().replace(/ /g, '_');

   res.redirect('/electionResults')
})

  // let elResults = fetch(`https://api.turbovote.org/elections/upcoming?district-divisions=ocd-division/country:us/state:${state},ocd-division/country:us/state:${state}/place:${place}`, {
  //   method: 'GET',
  //   headers: {
  //     Accept: 'application/json'
  //   }
  // })
  // .then(res => res.json())
  // .then(electionInfo => {
  //   return electionInfo[0]
  // })


module.exports = router;
