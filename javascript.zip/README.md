#This is a coding exercise
Using the Democracy Works Elections API this app allows users to search for information on upcoming elections in their city.



# Upcoming Elections Practical

This is a server-side web application written in JavaScript with
[Express][express] and [Handlebars][handlebars].

## Setup

    npm install

## Running

    DEBUG=js-upcoming-elections:* npm start

## Testing

    npm test

[express]: https://expressjs.com/
[handlebars]: http://handlebarsjs.com/
